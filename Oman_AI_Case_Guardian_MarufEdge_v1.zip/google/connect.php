<?php
// OAuth placeholder. Add Google API PHP client with Composer in production.
// Never collect Google passwords directly.
$config=require __DIR__.'/../config.php';
if(empty($config['google_client_id'])){
  http_response_code(503);
  echo '<h2>Google Drive is not configured yet.</h2><p>Add OAuth client ID/secret in config.php and configure the callback URL.</p>';
  exit;
}
echo 'OAuth setup required.';
