# Architecture

Browser
  -> PHP HTTPS API
     -> MySQL/MariaDB
     -> Evidence Vault
     -> Official-source index
     -> AI provider (server-side)
     -> Google Drive OAuth
     -> OCR / document extraction workers

## Agent roles
- LEGAL RESEARCHER: retrieves official rules and versions.
- EVIDENCE COLLECTOR: hashes, indexes, tags and links documents.
- CASE DETECTOR: compares facts/evidence to rule conditions.
- TIMELINE AGENT: extracts dates/events and finds chronology gaps.
- ALERT AGENT: monitors deadlines, missing evidence and source changes.
- AUDITOR: records who changed what and when.
- VOICE ASSISTANT: browser speech input/output.

## Guardrails
Every legal finding should contain:
source_id, citation, source_version/date, evidence_document_id, evidence_quote, confidence, reviewer_status.

The AI may say:
- "Potential issue detected"
- "Evidence appears consistent/inconsistent with..."
- "Needs human/legal review"

It should NOT say:
- "You will win"
- "The court must accept this"
- "I am your lawyer"
