# Oman Labour Rule Engine — initial rules

These are detector categories, not final legal conclusions.

R-001 CONTRACT_WORK_MISMATCH
Check whether documented actual duties differ materially from the written contract.
Relevant starting source: Oman Labour Law Royal Decree 53/2023, Article 53.
Human review required.

R-002 PASSPORT_RETENTION
Flag evidence that an employer retained a worker's passport/documents without written consent.
Starting source: Article 6.

R-003 FORCED_WORK_INDICATOR
Flag evidence suggesting forced/compulsory work.
Starting source: Article 5.

R-004 WAGE_EVIDENCE
Compare salary contract, bank statements, payroll/WPS records, receipts and deduction ledgers.
Use official WPS resources and current law/rules.

R-005 WORK_PERMIT_PROFESSION
Compare resident/work-permit profession, contract, actual duties and applicable licensing rules.
Check current Ministry rules and amendments.

R-006 EVIDENCE_CHAIN
For each material claim, require date + original document + source + relationship to the case.
Hash originals and keep immutable audit records where possible.
