const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const i18n={
 en:{title:"Oman AI Case Guardian",subtitle:"Evidence • Law Research • Case Timeline • Alerts"},
 bn:{title:"ওমান AI কেস গার্ডিয়ান",subtitle:"প্রমাণ • আইন গবেষণা • কেস টাইমলাইন • সতর্কতা"},
 ar:{title:"مساعد قضايا العمل في عُمان",subtitle:"الأدلة • البحث القانوني • الخط الزمني • التنبيهات"}
};
$$('.sidebar button[data-view]').forEach(b=>b.onclick=()=>{
 $$('.view').forEach(v=>v.classList.remove('active'));
 $('#'+b.dataset.view).classList.add('active');
});
$$('[data-lang]').forEach(b=>b.onclick=()=>{
 const l=b.dataset.lang; localStorage.lang=l;
 document.documentElement.lang=l;
 $$('[data-i18n]').forEach(e=>e.textContent=i18n[l][e.dataset.i18n]||e.textContent);
});
$('#analyze').onclick=async()=>{
 const q=$('#question').value.trim();
 if(!q)return;
 $('#analysis').innerHTML='<div class="result">Analyzing…</div>';
 const r=await fetch('api/analyze.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});
 const d=await r.json().catch(()=>({error:'Server response was not JSON'}));
 $('#analysis').innerHTML='<div class="result">'+escapeHtml(d.answer||d.error||'No result')+'</div>';
};
$('#researchBtn').onclick=async()=>{
 const q=$('#researchQ').value.trim();
 if(!q)return;
 $('#researchResults').innerHTML='<div class="result">Searching indexed official sources…</div>';
 const r=await fetch('api/research.php?q='+encodeURIComponent(q));
 const d=await r.json().catch(()=>({error:'Invalid response'}));
 $('#researchResults').innerHTML=(d.results||[]).map(x=>`<div class="result"><b>${escapeHtml(x.title)}</b><p>${escapeHtml(x.snippet||'')}</p><small>${escapeHtml(x.citation||'')}</small></div>`).join('')||'<div class="result">'+escapeHtml(d.error||'No indexed result')+'</div>';
};
$('#uploadBtn').onclick=async()=>{
 const fd=new FormData();
 [...$('#files').files].forEach(f=>fd.append('files[]',f));
 $('#uploadStatus').textContent='Uploading…';
 const r=await fetch('api/upload.php',{method:'POST',body:fd});
 const d=await r.json().catch(()=>({error:'Invalid response'}));
 $('#uploadStatus').textContent=d.message||d.error||'Done';
};
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
$('#mic').onclick=()=>{
 if(!SpeechRecognition){alert('Browser voice input is not available. Try a supported Chrome/Edge browser.');return}
 const r=new SpeechRecognition(); r.lang=(localStorage.lang==='bn'?'bn-BD':localStorage.lang==='ar'?'ar-OM':'en-US'); r.interimResults=false;
 r.onresult=e=>$('#question').value=e.results[0][0].transcript; r.start();
};
$('#speak').onclick=()=>{
 const t=$('.view.active')?.innerText||'';
 if('speechSynthesis' in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(t))}
};
