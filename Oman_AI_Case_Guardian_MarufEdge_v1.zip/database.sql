CREATE DATABASE IF NOT EXISTS oman_case_guardian
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE oman_case_guardian;

CREATE TABLE users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) UNIQUE,
  password_hash VARCHAR(255),
  role ENUM('owner','admin','editor','viewer') NOT NULL DEFAULT 'owner',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cases (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  case_no VARCHAR(80) NOT NULL UNIQUE,
  title VARCHAR(255) NOT NULL,
  language ENUM('en','bn','ar') NOT NULL DEFAULT 'en',
  status ENUM('open','monitoring','submitted','closed') NOT NULL DEFAULT 'open',
  description TEXT,
  risk_level ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  next_deadline DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE documents (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  case_id BIGINT UNSIGNED NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(500) NOT NULL,
  mime_type VARCHAR(180),
  file_size BIGINT UNSIGNED DEFAULT 0,
  sha256 CHAR(64),
  source ENUM('upload','google_drive','web') NOT NULL DEFAULT 'upload',
  extracted_text LONGTEXT,
  extraction_status ENUM('pending','complete','unsupported','failed') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE TABLE legal_sources (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  source_type ENUM('law','royal_decree','ministerial_decision','official_page','judgment','other') NOT NULL,
  citation VARCHAR(255),
  url VARCHAR(1000),
  version_date DATE NULL,
  content_hash CHAR(64),
  verified_official TINYINT(1) DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE findings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  case_id BIGINT UNSIGNED NOT NULL,
  document_id BIGINT UNSIGNED NULL,
  source_id BIGINT UNSIGNED NULL,
  rule_code VARCHAR(80),
  severity ENUM('info','warning','high','critical') DEFAULT 'info',
  finding_title VARCHAR(255) NOT NULL,
  finding_text TEXT NOT NULL,
  confidence DECIMAL(5,2) DEFAULT 0,
  evidence_quote TEXT,
  recommendation TEXT,
  status ENUM('open','reviewed','dismissed') DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE,
  FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL,
  FOREIGN KEY (source_id) REFERENCES legal_sources(id) ON DELETE SET NULL
);

CREATE TABLE timeline_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  case_id BIGINT UNSIGNED NOT NULL,
  event_date DATETIME NOT NULL,
  event_type VARCHAR(80),
  title VARCHAR(255) NOT NULL,
  details TEXT,
  document_id BIGINT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE TABLE alerts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  case_id BIGINT UNSIGNED NOT NULL,
  alert_type ENUM('deadline','rule_change','missing_evidence','research','system') NOT NULL,
  severity ENUM('info','warning','high','critical') DEFAULT 'warning',
  message TEXT NOT NULL,
  due_at DATETIME NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE TABLE audit_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NULL,
  action VARCHAR(120) NOT NULL,
  entity_type VARCHAR(80),
  entity_id BIGINT UNSIGNED NULL,
  details JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO legal_sources
(title, source_type, citation, url, version_date, verified_official, notes)
VALUES
('Oman Labour Law — Royal Decree 53/2023','royal_decree','Royal Decree 53/2023',
'https://www.mol.gov.om/Laborlaw?lid=102', '2023-07-25',1,
'Primary official Ministry of Labour Labour Law portal. Re-verify amendments before relying on a finding.'),
('Oman Wage Protection System','official_page','Ministry of Labour WPS',
'https://www.mol.gov.om/pages/Wps-Rules', NULL,1,
'Official Ministry of Labour wage rules/resources.'),
('Regulation of Work Permit and Work Practice Licensing','ministerial_decision','Ministerial Decision 602/2025',
'https://www.mol.gov.om/RegulationArticles', '2025-01-01',1,
'Use the official portal for current text. Check later amendments.'),
('Amendment to Decision 602/2025','ministerial_decision','Ministerial Decision 44/2026',
'https://qanoon.om/p/2026/mol20260044/', '2026-01-25',0,
'Secondary source copy; verify against official Gazette/Ministry before legal reliance.');
