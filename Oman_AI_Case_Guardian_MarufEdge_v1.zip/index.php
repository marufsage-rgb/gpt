<?php
session_start();
$config = file_exists(__DIR__.'/config.php') ? require __DIR__.'/config.php' : require __DIR__.'/config.example.php';
date_default_timezone_set($config['timezone'] ?? 'Asia/Muscat');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Oman AI Case Guardian</title>
<link rel="stylesheet" href="assets/app.css">
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="brand">⚖️ <span>Oman AI Case Guardian</span></div>
    <button data-view="dashboard">Dashboard</button>
    <button data-view="cases">Cases</button>
    <button data-view="evidence">Evidence Vault</button>
    <button data-view="detector">Rule Detector</button>
    <button data-view="research">Research Lab</button>
    <button data-view="drive">Google Drive</button>
    <button data-view="alerts">Live Alerts</button>
    <button data-view="audit">Audit Log</button>
    <div class="lang">
      <button data-lang="en">EN</button>
      <button data-lang="bn">বাংলা</button>
      <button data-lang="ar">العربية</button>
    </div>
  </aside>

  <main>
    <header class="top">
      <div>
        <h1 data-i18n="title">Oman AI Case Guardian</h1>
        <p data-i18n="subtitle">Evidence • Law Research • Case Timeline • Alerts</p>
      </div>
      <div class="voice">
        <button id="mic">🎙️ Voice</button>
        <button id="speak">🔊 Read</button>
      </div>
    </header>

    <section id="dashboard" class="view active">
      <div class="grid4">
        <div class="card metric"><b>1</b><span>Active Case</span></div>
        <div class="card metric"><b>0</b><span>Critical Alerts</span></div>
        <div class="card metric"><b>0</b><span>Documents</span></div>
        <div class="card metric"><b>0</b><span>Open Findings</span></div>
      </div>
      <div class="grid2">
        <article class="card">
          <h2>🧠 AI Legal Research Assistant</h2>
          <p>Ask a question, attach evidence, and require every legal conclusion to show its source and confidence.</p>
          <textarea id="question" placeholder="Example: Does this job assignment appear inconsistent with the written contract?"></textarea>
          <button class="primary" id="analyze">Analyze Case</button>
          <div id="analysis"></div>
        </article>
        <article class="card">
          <h2>🚨 Rule Detector</h2>
          <ul>
            <li>Contract vs actual work mismatch</li>
            <li>Wage/payment evidence gaps</li>
            <li>Passport/document retention indicators</li>
            <li>Forced/compulsory work indicators</li>
            <li>Work permit / profession mismatch</li>
            <li>Missing chronology or supporting evidence</li>
          </ul>
        </article>
      </div>
    </section>

    <section id="cases" class="view">
      <div class="card"><h2>Case Workspace</h2><input placeholder="Case No."><input placeholder="Case title"><textarea placeholder="Case facts"></textarea><button class="primary">Save Case</button></div>
    </section>

    <section id="evidence" class="view">
      <div class="card">
        <h2>📁 Evidence Vault</h2>
        <p>Upload originals. The server stores the original file hash and extraction status.</p>
        <input id="files" type="file" multiple>
        <button class="primary" id="uploadBtn">Upload / Index</button>
        <div id="uploadStatus"></div>
      </div>
    </section>

    <section id="detector" class="view">
      <div class="card"><h2>🔎 Oman Rule Detector</h2><p>Rule checks must be source-backed. The AI proposes issues; a human reviews before anything is treated as a legal position.</p><div id="rules"></div></div>
    </section>

    <section id="research" class="view">
      <div class="card"><h2>🔬 Research Laboratory</h2><input id="researchQ" placeholder="Search Oman Labour Law / Royal Decree / ministerial decision"><button class="primary" id="researchBtn">Research</button><div id="researchResults"></div></div>
    </section>

    <section id="drive" class="view">
      <div class="card"><h2>☁️ Google Drive</h2><p>Connect through OAuth. Never ask users to paste a Google password or API secret into this page.</p><a class="button" href="google/connect.php">Connect Google Drive</a></div>
    </section>

    <section id="alerts" class="view"><div class="card"><h2>🚨 Live Case Alerts</h2><div id="alertList"><p>No alerts yet.</p></div></div></section>
    <section id="audit" class="view"><div class="card"><h2>🧾 Audit Trail</h2><p>Every upload, finding review, source update and export should be logged here.</p></div></section>
  </main>
</div>
<script src="assets/app.js"></script>
</body>
</html>
