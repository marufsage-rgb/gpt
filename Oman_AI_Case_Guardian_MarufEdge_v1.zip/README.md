# Oman AI Case Guardian — MarufEdge
Multilingual (EN / বাংলা / العربية) legal-research and case-evidence organizer for Oman employment/labour matters.

IMPORTANT:
- This is a legal research/document-management assistant, NOT a lawyer, court, government service, or substitute for licensed legal advice.
- The system should prioritize official Oman sources and show source citations for every legal finding.
- Do not claim that an AI finding is a court judgment or guaranteed legal outcome.

## Main modules
1. Case dashboard
2. Evidence/file upload
3. Case timeline
4. Oman Labour Law rule detector
5. Research/source collector
6. Google Drive connector placeholder
7. AI summarizer/extractor
8. Alerts and deadlines
9. Audit log
10. EN / বাংলা / العربية UI
11. Browser voice input/output using Web Speech API when supported

## Current official reference baseline
- Oman Labour Law: Royal Decree 53/2023.
- Oman Ministry of Labour Labour Law portal.
- Ministry of Labour Wage Protection System pages.
- Labour licensing regulation 602/2025 and 2026/44 amendment should be treated as versioned sources.

The backend intentionally does not hard-code an API key. Put secrets in environment variables/server config.

## Suggested free/low-cost services
- Browser Web Speech API: voice input/output where supported by browser.
- Google Drive API + OAuth: API access is normally quota-based rather than per-request paid, subject to Google policies/quotas.
- Gemini API: use only an available current free tier/model and enforce daily limits; never expose the API key in frontend JavaScript.
- Official Oman MOL pages/PDFs: primary legal sources.
- MySQL/MariaDB: local/shared-host database.

## Production requirements
- HTTPS
- PHP 8.2+
- MySQL 8 / MariaDB 10.6+
- PHP extensions: PDO, mbstring, fileinfo, json, openssl
- For OCR: Tesseract or a server OCR service.
- For PDF/DOCX/XLSX extraction: install server-side parsers; uploaded originals remain stored even when extraction is unavailable.
- Google Drive requires OAuth client credentials and consent configuration.
