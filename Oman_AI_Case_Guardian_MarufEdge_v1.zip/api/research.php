<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__.'/db.php';
$q=trim($_GET['q']??'');
if($q===''){echo json_encode(['results'=>[]]);exit;}
$stmt=$pdo->prepare("SELECT title,citation,url,notes FROM legal_sources WHERE title LIKE ? OR citation LIKE ? OR notes LIKE ? ORDER BY verified_official DESC, id DESC LIMIT 20");
$like='%'.$q.'%';$stmt->execute([$like,$like,$like]);
$rows=$stmt->fetchAll();
foreach($rows as &$r){$r['snippet']=$r['notes'];}
echo json_encode(['results'=>$rows],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
