<?php
header('Content-Type: application/json; charset=utf-8');
$config=require __DIR__.'/../config.php';
if(empty($_FILES['files'])){http_response_code(400);echo json_encode(['error'=>'No files received']);exit;}
$dir=__DIR__.'/../storage/uploads'; if(!is_dir($dir)) mkdir($dir,0750,true);
$out=[];
foreach($_FILES['files']['name'] as $i=>$name){
  if($_FILES['files']['error'][$i]!==UPLOAD_ERR_OK) continue;
  $tmp=$_FILES['files']['tmp_name'][$i];
  $size=(int)$_FILES['files']['size'][$i];
  if($size>($config['upload_max_mb']*1024*1024)) continue;
  $safe=preg_replace('/[^A-Za-z0-9._-]/','_',basename($name));
  $stored=bin2hex(random_bytes(12)).'_'.$safe;
  $path=$dir.'/'.$stored;
  move_uploaded_file($tmp,$path);
  $out[]=['name'=>$name,'stored'=>$stored,'sha256'=>hash_file('sha256',$path),'size'=>$size];
}
echo json_encode(['message'=>count($out).' file(s) indexed','files'=>$out],JSON_UNESCAPED_UNICODE);
