<?php
header('Content-Type: application/json; charset=utf-8');
$config=require __DIR__.'/../config.php';
$input=json_decode(file_get_contents('php://input'),true) ?: [];
$q=trim($input['question']??'');
if(!$q){http_response_code(400);echo json_encode(['error'=>'Question is required']);exit;}
/*
Production flow:
1. Retrieve relevant indexed documents + official legal sources.
2. Build a citation-first prompt.
3. Call Gemini server-side using the API key from config/environment.
4. Require structured JSON: findings, citations, confidence, missing_evidence.
5. Store the result and audit event.
*/
$answer="Research mode is ready. For production AI analysis, configure a current Gemini API model server-side. The system should never present an uncited AI conclusion as law. Query received: ".$q;
echo json_encode(['answer'=>$answer,'mode'=>'citation-first']);
