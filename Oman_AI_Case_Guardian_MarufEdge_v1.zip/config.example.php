<?php
// Copy to config.php and edit for your server.
// NEVER commit real secrets to GitHub.

return [
    'app_name' => 'Oman AI Case Guardian',
    'timezone' => 'Asia/Muscat',

    'db' => [
        'host' => 'localhost',
        'name' => 'oman_case_guardian',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],

    // Keep server-side only.
    'gemini_api_key' => '',
    'gemini_model' => 'YOUR_CURRENT_AVAILABLE_MODEL',

    // Google Drive OAuth credentials. Store JSON securely outside public_html.
    'google_client_id' => '',
    'google_client_secret' => '',
    'google_redirect_uri' => 'https://YOUR-DOMAIN.example.com/google/callback.php',

    'upload_max_mb' => 50,
];
