<?php
require __DIR__.'/bootstrap.php';
$m=$_SERVER['REQUEST_METHOD'];
if($m==='POST'){
 $b=body();$no=trim($b['case_no']??'');$title=trim($b['title']??'');
 if(!$no||!$title){http_response_code(422);out(['error'=>'case_no and title required']);exit;}
 $s=$pdo->prepare("INSERT INTO cases(case_no,title,language,description) VALUES(?,?,?,?)");
 $s->execute([$no,$title,$b['language']??'en',$b['description']??'']);out(['id'=>$pdo->lastInsertId()]);
 exit;
}
$s=$pdo->query("SELECT * FROM cases ORDER BY updated_at DESC LIMIT 100");out(['cases'=>$s->fetchAll()]);
