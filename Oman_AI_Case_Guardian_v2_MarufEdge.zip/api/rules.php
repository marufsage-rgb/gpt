<?php
require __DIR__.'/bootstrap.php';
$s=$pdo->query("SELECT r.*,ls.title source_title,ls.url FROM rules r LEFT JOIN legal_sources ls ON ls.id=r.source_id WHERE r.active=1 ORDER BY r.code");
out(['rules'=>$s->fetchAll()]);
