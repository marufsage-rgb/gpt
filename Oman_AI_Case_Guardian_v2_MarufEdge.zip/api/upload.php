<?php
require __DIR__.'/bootstrap.php';
$config=require __DIR__.'/../config.php';
$caseId=(int)($_POST['case_id']??0);
if(!$caseId){http_response_code(422);out(['error'=>'case_id required']);exit;}
if(empty($_FILES['files'])){http_response_code(400);out(['error'=>'No files']);exit;}
$dir=__DIR__.'/../storage/uploads';if(!is_dir($dir))mkdir($dir,0750,true);
$allowed=$config['uploads']['allowed_ext'];$max=$config['uploads']['max_mb']*1024*1024;$rows=[];
foreach($_FILES['files']['name'] as $i=>$name){
 if($_FILES['files']['error'][$i]!==UPLOAD_ERR_OK)continue;
 $size=(int)$_FILES['files']['size'][$i];$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
 if($size>$max||!in_array($ext,$allowed,true))continue;
 $safe=preg_replace('/[^A-Za-z0-9._-]/','_',basename($name));
 $stored=bin2hex(random_bytes(16)).'_'.$safe;$path=$dir.'/'.$stored;
 if(!move_uploaded_file($_FILES['files']['tmp_name'][$i],$path))continue;
 $sha=hash_file('sha256',$path);$mime=(new finfo(FILEINFO_MIME_TYPE))->file($path);
 $s=$pdo->prepare("INSERT INTO documents(case_id,original_name,stored_path,mime_type,extension,file_size,sha256) VALUES(?,?,?,?,?,?,?)");
 $s->execute([$caseId,$name,$stored,$mime,$ext,$size,$sha]);
 $rows[]=['id'=>$pdo->lastInsertId(),'name'=>$name,'sha256'=>$sha,'status'=>'pending extraction'];
}
out(['uploaded'=>$rows]);
