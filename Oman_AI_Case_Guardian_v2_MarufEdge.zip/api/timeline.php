<?php
require __DIR__.'/bootstrap.php';
$case=(int)($_GET['case_id']??0);
$s=$pdo->prepare("SELECT * FROM timeline WHERE case_id=? ORDER BY event_date ASC");$s->execute([$case]);
out(['events'=>$s->fetchAll()]);
