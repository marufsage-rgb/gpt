<?php
$config=require __DIR__.'/../config.php';
date_default_timezone_set($config['timezone']??'Asia/Muscat');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
$dsn="mysql:host={$config['db']['host']};dbname={$config['db']['name']};charset={$config['db']['charset']}";
try{$pdo=new PDO($dsn,$config['db']['user'],$config['db']['pass'],[
PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
]);}catch(Throwable $e){http_response_code(500);echo json_encode(['error'=>'Database unavailable']);exit;}
function body(){return json_decode(file_get_contents('php://input'),true)?:[];}
function out($x){echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
