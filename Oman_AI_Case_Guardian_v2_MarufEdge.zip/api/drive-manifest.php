<?php
require __DIR__.'/bootstrap.php';
// OAuth connector intentionally kept separate. After Google OAuth, Drive file metadata
// should be imported into documents with source='google_drive' and its Drive file ID
// stored in a dedicated integration table in production.
out(['status'=>'oauth-required','message'=>'Connect Google Drive using OAuth; do not collect Google passwords.']);
