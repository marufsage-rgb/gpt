<?php
require __DIR__.'/bootstrap.php';
$q=trim($_GET['q']??'');
if(!$q){out(['results'=>[]]);exit;}
$s=$pdo->prepare("SELECT id,title,citation,url,version_date,verified_official,notes FROM legal_sources WHERE title LIKE ? OR citation LIKE ? OR notes LIKE ? ORDER BY verified_official DESC,version_date DESC LIMIT 30");
$x='%'.$q.'%';$s->execute([$x,$x,$x]);out(['results'=>$s->fetchAll()]);
