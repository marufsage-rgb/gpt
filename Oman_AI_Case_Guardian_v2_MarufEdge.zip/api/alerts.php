<?php
require __DIR__.'/bootstrap.php';
$s=$pdo->query("SELECT a.*,c.case_no,c.title FROM alerts a LEFT JOIN cases c ON c.id=a.case_id WHERE a.is_read=0 ORDER BY a.severity DESC,a.due_at ASC LIMIT 100");
out(['alerts'=>$s->fetchAll()]);
