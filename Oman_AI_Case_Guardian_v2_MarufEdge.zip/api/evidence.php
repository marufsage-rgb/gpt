<?php
require __DIR__.'/bootstrap.php';
$case=(int)($_GET['case_id']??0);
$s=$pdo->prepare("SELECT d.*,f.title AS finding_title FROM documents d LEFT JOIN findings f ON f.document_id=d.id WHERE d.case_id=? ORDER BY d.created_at DESC");
$s->execute([$case]);out(['documents'=>$s->fetchAll()]);
