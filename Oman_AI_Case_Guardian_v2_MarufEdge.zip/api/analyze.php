<?php
require __DIR__.'/bootstrap.php';
$q=trim(body()['question']??'');
if(!$q){http_response_code(400);out(['error'=>'Question required']);exit;}
/*
Production AI contract:
- retrieve relevant official sources and evidence
- send only necessary data to provider
- request JSON: findings[], citations[], missing_evidence[], confidence
- reject uncited legal assertions
- save response + model + timestamp + source IDs in audit log
*/
out(['status'=>'ready','answer'=>'AI citation-first analysis endpoint ready. Configure the server-side AI provider and retrieval layer before using this for legal research.','question'=>$q,'guardrail'=>'Human legal review required.']);
