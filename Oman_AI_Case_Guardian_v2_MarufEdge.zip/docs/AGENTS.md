# Agent orchestration

RESEARCHER
-> searches indexed official sources
-> ranks official sources above secondary sources
-> returns citation IDs

COLLECTOR
-> indexes uploaded/Drive documents
-> hashes originals
-> extracts text/OCR
-> detects duplicates

DETECTOR
-> evaluates versioned rules against evidence
-> creates findings, not verdicts

TIMELINE
-> extracts dates and events
-> detects chronology conflicts/gaps

ALERT
-> deadlines, missing evidence, source/rule updates

AUDITOR
-> records every meaningful action

VOICE
-> speech-to-text / text-to-speech in EN/BN/AR

Recommended AI output JSON:
{
 "findings": [{"rule_code":"","severity":"","analysis":"","evidence_quote":"","source_ids":[],"confidence":0}],
 "missing_evidence": [],
 "timeline_events": [],
 "disclaimer": "Human/legal review required."
}
