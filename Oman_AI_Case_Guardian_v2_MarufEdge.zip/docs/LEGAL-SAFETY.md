# Legal safety model

1. Official-source-first: Ministry of Labour and Royal Decree sources are primary.
2. Secondary copies may help discovery but cannot silently replace an official source.
3. Every AI finding requires citation + evidence link + confidence.
4. Human review is mandatory before filing, sending, or representing a finding as a legal conclusion.
5. Preserve originals and SHA-256 hashes.
6. Never store passwords, OTPs, bank PINs or Google credentials.
7. Minimize personal data sent to AI providers.
8. Provide delete/export controls and access logging.
9. Do not predict a court outcome as fact.
10. Display source version/date because laws and decisions can be amended.
