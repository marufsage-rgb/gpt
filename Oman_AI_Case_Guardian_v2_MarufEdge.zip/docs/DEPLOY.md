# Deploy

1. Create MySQL database.
2. Import database.sql.
3. Copy config.example.php -> config.php and add DB credentials.
4. Keep config.php outside public web root where possible.
5. Ensure storage/uploads is writable by PHP.
6. Use HTTPS.
7. Point cron to cron/alerts.php.
8. Install server-side parsers for PDF/DOCX/XLSX/OCR if extraction is required.
9. Install Google API PHP Client and configure OAuth for Drive.
10. Configure an available current AI model server-side; never expose API keys in app.js.
11. Add authentication before production use.
12. Back up database + evidence originals separately.
