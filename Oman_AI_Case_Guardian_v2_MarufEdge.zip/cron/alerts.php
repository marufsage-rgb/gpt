<?php
// Run every 15-60 minutes from cron.
require __DIR__.'/../api/bootstrap.php';
$pdo->exec("INSERT INTO alerts(case_id,type,severity,message,due_at)
SELECT id,'deadline',CASE WHEN next_deadline<NOW()+INTERVAL 2 DAY THEN 'high' ELSE 'warning' END,
CONCAT('Case deadline approaching: ',case_no),next_deadline
FROM cases WHERE next_deadline IS NOT NULL AND next_deadline BETWEEN NOW() AND NOW()+INTERVAL 7 DAY
AND NOT EXISTS(SELECT 1 FROM alerts a WHERE a.case_id=cases.id AND a.type='deadline' AND DATE(a.due_at)=DATE(cases.next_deadline))");
echo "alerts checked
";
