<?php
$config=require __DIR__.'/../config.php';
if(empty($config['google']['client_id'])){http_response_code(503);exit('Google Drive OAuth is not configured.');}
echo 'Google OAuth client configuration is present; install Google API PHP Client and complete OAuth flow.';
